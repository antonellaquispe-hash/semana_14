package com.tecsup.model;
import jakarta.persistence.*;
@Entity
@Table(name="categoria")
public class Categoria {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 private String nombre;
 private String estado;
 public Categoria() {}
 public Categoria(String nombre, String estado) { this.nombre=nombre; this.estado=estado; }
 public Long getId(){return id;} public void setId(Long id){this.id=id;}
 public String getNombre(){return nombre;} public void setNombre(String nombre){this.nombre=nombre;}
 public String getEstado(){return estado;} public void setEstado(String estado){this.estado=estado;}
}
